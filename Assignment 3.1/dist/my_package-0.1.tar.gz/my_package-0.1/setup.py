from setuptools import setup
setup(name='my_package',
version='0.1',
description='run ingest.py, train.py and score.py',
url='#',
author='auth',
author_email='ronak.shah@tigeranlytics.com',
license='MIT',
packages=['my_package'],
zip_safe=False)